"""
GTK 3 Graphical User Interface for Codex Desktop Linux.
Features:
- Background Codex app-server supervision and status indicator
- Thread list in sidebar with search and timestamp
- 'Nouveau chat' (New chat) button
- Interactive chat conversation view with formatted bubbles
- Real-time streaming response rendering
- Thread resumption and message history
- Command / file approval notifications
- Settings dialog (model, cwd, codex path, restart)
"""

import os
import sys
import logging
import threading
from pathlib import Path
from typing import Optional, Dict, Any, List

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, Gdk, GLib, Pango

from codex_desktop.config import Config, DEFAULT_MODELS
from codex_desktop.storage import Storage
from codex_desktop.process_manager import ProcessManager, ServerStatus

logger = logging.getLogger("codex_desktop.ui")

class MessageBubble(Gtk.Box):
    def __init__(self, role: str, content: str, timestamp: float = 0.0):
        super().__init__(orientation=Gtk.Orientation.VERTICAL, spacing=4)
        self.role = role
        self.set_margin_top(6)
        self.set_margin_bottom(6)
        self.set_margin_start(16)
        self.set_margin_end(16)

        # Header: Role label + time
        header_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        role_label = Gtk.Label()
        role_label.set_xalign(0.0)

        if role == "user":
            role_label.set_markup("<b>Vous</b>")
            self.set_halign(Gtk.Align.END)
        else:
            role_label.set_markup("<span foreground='#10a37f'><b>Codex</b></span>")
            self.set_halign(Gtk.Align.START)

        header_box.pack_start(role_label, False, False, 0)
        self.pack_start(header_box, False, False, 0)

        # Content frame / text view
        self.content_frame = Gtk.Frame()
        self.content_frame.set_shadow_type(Gtk.ShadowType.ETCHED_IN)

        self.text_view = Gtk.TextView()
        self.text_view.set_editable(False)
        self.text_view.set_cursor_visible(False)
        self.text_view.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.text_view.set_left_margin(12)
        self.text_view.set_right_margin(12)
        self.text_view.set_top_margin(8)
        self.text_view.set_bottom_margin(8)

        # Set style class
        ctx = self.content_frame.get_style_context()
        if role == "user":
            ctx.add_class("user-bubble")
        else:
            ctx.add_class("assistant-bubble")

        self.text_buffer = self.text_view.get_buffer()
        self.text_buffer.set_text(content)

        self.content_frame.add(self.text_view)
        self.pack_start(self.content_frame, True, True, 0)
        self.show_all()

    def append_text(self, delta: str):
        end_iter = self.text_buffer.get_end_iter()
        self.text_buffer.insert(end_iter, delta)

    def set_text(self, text: str):
        self.text_buffer.set_text(text)

    def get_text(self) -> str:
        start_iter = self.text_buffer.get_start_iter()
        end_iter = self.text_buffer.get_end_iter()
        return self.text_buffer.get_text(start_iter, end_iter, True)


class CodexDesktopWindow(Gtk.Window):
    def __init__(self, config: Config, storage: Storage, process_manager: ProcessManager):
        super().__init__(title="Codex Desktop")
        self.config = config
        self.storage = storage
        self.pm = process_manager

        self.current_thread_id: Optional[str] = None
        self.current_turn_id: Optional[str] = None
        self.current_streaming_bubble: Optional[MessageBubble] = None
        self.current_streaming_msg_id: Optional[int] = None
        self.is_generating = False

        self.set_default_size(980, 680)
        self.set_position(Gtk.WindowPosition.CENTER)

        self._setup_css()
        self._build_header_bar()
        self._build_ui()

        # Connect ProcessManager callbacks
        self.pm.on_status_change = self._on_server_status_change

        # Start background server
        self._start_server_async()

        # Load initial threads
        self._refresh_thread_list()

    def _setup_css(self):
        css_data = b"""
        .user-bubble {
            background-color: #2b5278;
            border-radius: 8px;
        }
        .user-bubble text {
            color: #ffffff;
            background-color: #2b5278;
        }
        .assistant-bubble {
            background-color: #242424;
            border-radius: 8px;
        }
        .assistant-bubble text {
            color: #e0e0e0;
            background-color: #242424;
        }
        .status-badge-running {
            color: #10a37f;
            font-weight: bold;
        }
        .status-badge-mock {
            color: #e6a23c;
            font-weight: bold;
        }
        .status-badge-stopped {
            color: #f56c6c;
        }
        """
        provider = Gtk.CssProvider()
        provider.load_from_data(css_data)
        screen = Gdk.Screen.get_default()
        if screen:
            Gtk.StyleContext.add_provider_for_screen(
                screen, provider, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION
            )

    def _build_header_bar(self):
        header = Gtk.HeaderBar()
        header.set_show_close_button(True)
        header.set_title("Codex Desktop")
        header.set_subtitle("Linux Unofficial Client")

        # New chat button
        btn_new = Gtk.Button.new_from_icon_name("list-add-symbolic", Gtk.IconSize.BUTTON)
        btn_new.set_tooltip_text("Nouveau chat")
        btn_new.connect("clicked", lambda _: self.on_new_chat_clicked())
        header.pack_start(btn_new)

        # Status badge label
        self.status_label = Gtk.Label(label="Initialisation...")
        header.pack_end(self.status_label)

        # Model Selector combo
        self.model_combo = Gtk.ComboBoxText()
        for model_id, model_name in DEFAULT_MODELS:
            self.model_combo.append(model_id, model_name)
        self.model_combo.set_active_id(self.config.default_model)
        self.model_combo.connect("changed", self._on_model_changed)
        header.pack_end(self.model_combo)

        # Settings button
        btn_settings = Gtk.Button.new_from_icon_name("emblem-system-symbolic", Gtk.IconSize.BUTTON)
        btn_settings.set_tooltip_text("Paramètres & Serveur")
        btn_settings.connect("clicked", lambda _: self._open_settings_dialog())
        header.pack_end(btn_settings)

        self.set_titlebar(header)

    def _build_ui(self):
        main_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        self.add(main_box)

        # Left Sidebar (Threads list)
        sidebar = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        sidebar.set_size_request(260, -1)
        sidebar.set_margin_top(8)
        sidebar.set_margin_bottom(8)
        sidebar.set_margin_start(8)
        sidebar.set_margin_end(4)

        # "Nouveau Chat" large button in sidebar
        new_chat_btn = Gtk.Button.new_with_label("＋  Nouveau chat")
        new_chat_btn.connect("clicked", lambda _: self.on_new_chat_clicked())
        sidebar.pack_start(new_chat_btn, False, False, 0)

        # Search / filter box
        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Rechercher un chat...")
        self.search_entry.connect("search-changed", lambda _: self._refresh_thread_list())
        sidebar.pack_start(self.search_entry, False, False, 0)

        # Threads ScrolledWindow + ListBox
        scrolled_threads = Gtk.ScrolledWindow()
        scrolled_threads.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.thread_listbox = Gtk.ListBox()
        self.thread_listbox.set_selection_mode(Gtk.SelectionMode.SINGLE)
        self.thread_listbox.connect("row-selected", self._on_thread_selected)
        scrolled_threads.add(self.thread_listbox)
        sidebar.pack_start(scrolled_threads, True, True, 0)

        main_box.pack_start(sidebar, False, False, 0)

        # Separator
        sep = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        main_box.pack_start(sep, False, False, 0)

        # Right Area (Chat area)
        chat_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=6)
        chat_box.set_margin_top(8)
        chat_box.set_margin_bottom(8)
        chat_box.set_margin_start(4)
        chat_box.set_margin_end(8)

        # Thread info banner
        self.thread_title_label = Gtk.Label()
        self.thread_title_label.set_markup("<b>Nouvelle conversation</b>")
        self.thread_title_label.set_xalign(0.0)
        chat_box.pack_start(self.thread_title_label, False, False, 4)

        # Messages ScrolledWindow
        self.scrolled_messages = Gtk.ScrolledWindow()
        self.scrolled_messages.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        self.messages_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        self.scrolled_messages.add(self.messages_box)
        chat_box.pack_start(self.scrolled_messages, True, True, 0)

        # Bottom Input area
        input_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=4)

        # Status / Generating indicator
        self.gen_bar = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        self.spinner = Gtk.Spinner()
        self.gen_label = Gtk.Label(label="Codex réfléchit...")
        self.btn_stop = Gtk.Button.new_with_label("Arrêter")
        self.btn_stop.connect("clicked", lambda _: self._stop_generation())
        self.gen_bar.pack_start(self.spinner, False, False, 0)
        self.gen_bar.pack_start(self.gen_label, False, False, 0)
        self.gen_bar.pack_end(self.btn_stop, False, False, 0)
        input_container.pack_start(self.gen_bar, False, False, 0)
        self.gen_bar.set_no_show_all(True)
        self.gen_bar.hide()

        # Text input & send button
        input_box = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)

        scrolled_input = Gtk.ScrolledWindow()
        scrolled_input.set_policy(Gtk.PolicyType.AUTOMATIC, Gtk.PolicyType.AUTOMATIC)
        scrolled_input.set_min_content_height(50)
        scrolled_input.set_max_content_height(120)

        self.input_textview = Gtk.TextView()
        self.input_textview.set_wrap_mode(Gtk.WrapMode.WORD_CHAR)
        self.input_textview.set_left_margin(8)
        self.input_textview.set_right_margin(8)
        self.input_textview.set_top_margin(6)
        self.input_textview.set_bottom_margin(6)
        self.input_textview.connect("key-press-event", self._on_input_key_press)
        scrolled_input.add(self.input_textview)
        input_box.pack_start(scrolled_input, True, True, 0)

        self.btn_send = Gtk.Button.new_from_icon_name("mail-send-symbolic", Gtk.IconSize.BUTTON)
        self.btn_send.set_tooltip_text("Envoyer (Entrée)")
        self.btn_send.connect("clicked", lambda _: self.on_send_clicked())
        input_box.pack_start(self.btn_send, False, False, 0)

        input_container.pack_start(input_box, False, False, 0)
        chat_box.pack_start(input_container, False, False, 0)

        main_box.pack_start(chat_box, True, True, 0)

    def _start_server_async(self):
        def worker():
            try:
                client = self.pm.start_server()
                client.on_delta = self._on_client_delta
                client.on_turn_completed = self._on_client_turn_completed
                client.on_approval_request = self._on_client_approval_request
            except Exception as e:
                logger.error("Failed to start server: %s", e)

        t = threading.Thread(target=worker, daemon=True, name="CodexStartWorker")
        t.start()

    def _on_server_status_change(self, status: str, detail: str):
        GLib.idle_add(self._update_status_ui, status, detail)

    def _update_status_ui(self, status: str, detail: str):
        if status == ServerStatus.RUNNING:
            markup = f"<span foreground='#10a37f'>● {status}</span>"
        elif status == ServerStatus.MOCK_MODE:
            markup = f"<span foreground='#e6a23c'>● {status}</span>"
        elif status == ServerStatus.STARTING:
            markup = f"<span foreground='#409eff'>⏳ {status}</span>"
        else:
            markup = f"<span foreground='#f56c6c'>● {status}</span>"
        self.status_label.set_markup(markup)
        if detail:
            self.status_label.set_tooltip_text(detail)

    def _on_model_changed(self, combo):
        model_id = combo.get_active_id()
        if model_id:
            self.config.default_model = model_id
            self.config.save()

    def _refresh_thread_list(self):
        for child in self.thread_listbox.get_children():
            self.thread_listbox.remove(child)

        query = self.search_entry.get_text().strip().lower()
        threads = self.storage.list_threads()

        for th in threads:
            if query and query not in th["title"].lower():
                continue

            row = Gtk.ListBoxRow()
            row.thread_id = th["id"]

            hbox = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
            hbox.set_margin_top(6)
            hbox.set_margin_bottom(6)
            hbox.set_margin_start(8)
            hbox.set_margin_end(8)

            vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
            title_lbl = Gtk.Label(label=th["title"])
            title_lbl.set_xalign(0.0)
            title_lbl.set_ellipsize(Pango.EllipsizeMode.END)
            title_lbl.set_max_width_chars(22)

            sub_lbl = Gtk.Label(label=th["model"])
            sub_lbl.set_xalign(0.0)
            sub_lbl.set_markup(f"<small><span foreground='#888888'>{th['model']}</span></small>")

            vbox.pack_start(title_lbl, False, False, 0)
            vbox.pack_start(sub_lbl, False, False, 0)
            hbox.pack_start(vbox, True, True, 0)

            # Delete button
            del_btn = Gtk.Button.new_from_icon_name("user-trash-symbolic", Gtk.IconSize.MENU)
            del_btn.set_relief(Gtk.ReliefStyle.NONE)
            del_btn.set_tooltip_text("Supprimer ce chat")
            del_btn.connect("clicked", lambda _, tid=th["id"]: self._delete_thread(tid))
            hbox.pack_end(del_btn, False, False, 0)

            row.add(hbox)
            self.thread_listbox.add(row)

        self.thread_listbox.show_all()

    def _on_thread_selected(self, listbox, row):
        if not row:
            return
        thread_id = getattr(row, "thread_id", None)
        if thread_id and thread_id != self.current_thread_id:
            self.resume_thread(thread_id)

    def on_new_chat_clicked(self):
        self.current_thread_id = None
        self.current_turn_id = None
        self.thread_title_label.set_markup("<b>Nouvelle conversation</b>")

        # Clear messages view
        for child in self.messages_box.get_children():
            self.messages_box.remove(child)

        buf = self.input_textview.get_buffer()
        buf.set_text("")
        self.input_textview.grab_focus()

    def resume_thread(self, thread_id: str):
        self.current_thread_id = thread_id
        th = self.storage.get_thread(thread_id)
        if not th:
            return

        self.thread_title_label.set_markup(f"<b>{th['title']}</b> ({th['model']})")

        # Clear and load messages from storage
        for child in self.messages_box.get_children():
            self.messages_box.remove(child)

        messages = self.storage.list_messages(thread_id)
        for msg in messages:
            bubble = MessageBubble(msg["role"], msg["content"], msg["created_at"])
            self.messages_box.pack_start(bubble, False, False, 0)

        self.messages_box.show_all()
        self._scroll_to_bottom()

        # Send thread/resume to server in background
        if self.pm.client and self.pm.is_alive():
            def worker():
                try:
                    self.pm.client.thread_resume(thread_id)
                    logger.info("Resumed thread %s on server", thread_id)
                except Exception as e:
                    logger.warning("Could not resume thread on server (will start turn directly): %s", e)
            threading.Thread(target=worker, daemon=True).start()

    def _delete_thread(self, thread_id: str):
        self.storage.delete_thread(thread_id)
        if self.current_thread_id == thread_id:
            self.on_new_chat_clicked()
        self._refresh_thread_list()

    def _on_input_key_press(self, widget, event):
        # Enter without Shift/Ctrl sends message
        if event.keyval in (Gdk.KEY_Return, Gdk.KEY_KP_Enter):
            if not (event.state & (Gdk.ModifierType.SHIFT_MASK | Gdk.ModifierType.CONTROL_MASK)):
                self.on_send_clicked()
                return True
        return False

    def on_send_clicked(self):
        if self.is_generating:
            return

        buf = self.input_textview.get_buffer()
        start_iter = buf.get_start_iter()
        end_iter = buf.get_end_iter()
        text = buf.get_text(start_iter, end_iter, True).strip()
        if not text:
            return

        # Clear input
        buf.set_text("")

        # Add user message to UI and storage
        if not self.current_thread_id:
            title = text[:30] + ("..." if len(text) > 30 else "")
            new_th = self.storage.save_thread(
                thread_id="",  # will update after server creates thread
                title=title,
                model=self.config.default_model,
                cwd=os.getcwd()
            )

        # If thread already exists, store user message immediately
        if self.current_thread_id:
            self.storage.add_message(self.current_thread_id, "user", text)

        # Add user bubble
        user_bubble = MessageBubble("user", text)
        self.messages_box.pack_start(user_bubble, False, False, 0)

        # Prepare assistant bubble
        assistant_bubble = MessageBubble("assistant", "")
        self.messages_box.pack_start(assistant_bubble, False, False, 0)
        self.current_streaming_bubble = assistant_bubble

        self.messages_box.show_all()
        self._scroll_to_bottom()

        # UI state: generating
        self._set_generating(True)

        # Start thread / turn asynchronously
        threading.Thread(target=self._execute_turn, args=(text,), daemon=True).start()

    def _execute_turn(self, prompt: str):
        try:
            if not self.pm.is_alive() or not self.pm.client:
                self.pm.start_server()

            client = self.pm.client

            # Create thread on server if needed
            if not self.current_thread_id:
                model = self.config.default_model
                thread_id = client.thread_start(
                    model=model,
                    cwd=os.getcwd(),
                    approval_policy=self.config.approval_policy,
                    sandbox=self.config.sandbox
                )
                self.current_thread_id = thread_id
                title = prompt[:30] + ("..." if len(prompt) > 30 else "")
                self.storage.save_thread(thread_id, title, model, os.getcwd())
                self.storage.add_message(thread_id, "user", prompt)
                GLib.idle_add(self._on_new_thread_created, thread_id, title)

            # Store assistant message placeholder in storage
            msg_id = self.storage.add_message(self.current_thread_id, "assistant", "", status="in_progress")
            self.current_streaming_msg_id = msg_id

            # Start turn
            turn_id = client.turn_start(self.current_thread_id, prompt)
            self.current_turn_id = turn_id

        except Exception as e:
            logger.exception("Failed to execute turn: %s", e)
            GLib.idle_add(self._on_turn_error, str(e))

    def _on_new_thread_created(self, thread_id: str, title: str):
        self.thread_title_label.set_markup(f"<b>{title}</b> ({self.config.default_model})")
        self._refresh_thread_list()

    def _on_client_delta(self, item_id: str, delta: str):
        GLib.idle_add(self._append_delta_ui, delta)

    def _append_delta_ui(self, delta: str):
        if self.current_streaming_bubble:
            self.current_streaming_bubble.append_text(delta)
            self._scroll_to_bottom()

    def _on_client_turn_completed(self, params: Dict[str, Any]):
        GLib.idle_add(self._finalize_turn_ui)

    def _finalize_turn_ui(self):
        if self.current_streaming_bubble and self.current_streaming_msg_id:
            full_text = self.current_streaming_bubble.get_text()
            self.storage.update_message(self.current_streaming_msg_id, full_text, status="completed")
            if self.current_thread_id:
                self.storage.update_thread_timestamp(self.current_thread_id)

        self._set_generating(False)
        self.current_streaming_bubble = None
        self.current_streaming_msg_id = None
        self.current_turn_id = None
        self._refresh_thread_list()

    def _on_turn_error(self, err_msg: str):
        if self.current_streaming_bubble:
            self.current_streaming_bubble.append_text(f"\n\n[Erreur: {err_msg}]")
        self._set_generating(False)

    def _set_generating(self, state: bool):
        self.is_generating = state
        self.btn_send.set_sensitive(not state)
        if state:
            self.spinner.start()
            self.gen_bar.show()
        else:
            self.spinner.stop()
            self.gen_bar.hide()

    def _stop_generation(self):
        if self.current_thread_id and self.current_turn_id and self.pm.client:
            def worker():
                try:
                    self.pm.client.turn_interrupt(self.current_thread_id, self.current_turn_id)
                except Exception as e:
                    logger.error("Failed to interrupt turn: %s", e)
            threading.Thread(target=worker, daemon=True).start()

    def _on_client_approval_request(self, method: str, req_id: int, params: Dict[str, Any]) -> str:
        # Prompt user on main UI thread with dialog
        decision = ["accept"]
        event = threading.Event()

        def ask_dialog():
            cmd = params.get("command", "")
            reason = params.get("reason", "Approbation requise par Codex")
            msg = f"Codex demande l'approbation pour exécuter :\n\n{cmd or reason}\n\nAutoriser cette action ?"

            dlg = Gtk.MessageDialog(
                transient_for=self,
                flags=0,
                message_type=Gtk.MessageType.QUESTION,
                buttons=Gtk.ButtonsType.YES_NO,
                text="Demande d'approbation Codex"
            )
            dlg.format_secondary_text(msg)
            response = dlg.run()
            dlg.destroy()

            if response == Gtk.ResponseType.YES:
                decision[0] = "accept"
            else:
                decision[0] = "decline"
            event.set()

        GLib.idle_add(ask_dialog)
        event.wait(timeout=60.0)
        return decision[0]

    def _scroll_to_bottom(self):
        adj = self.scrolled_messages.get_vadjustment()
        GLib.idle_add(lambda: adj.set_value(adj.get_upper() - adj.get_page_size()))

    def _open_settings_dialog(self):
        dlg = Gtk.Dialog(
            title="Paramètres Codex Desktop",
            transient_for=self,
            flags=0
        )
        dlg.add_button("Fermer", Gtk.ResponseType.CLOSE)
        dlg.set_default_size(450, 320)

        box = dlg.get_content_area()
        box.set_spacing(12)
        box.set_margin_top(12)
        box.set_margin_bottom(12)
        box.set_margin_start(16)
        box.set_margin_end(16)

        # Codex bin path entry
        box.pack_start(Gtk.Label(label="<b>Chemin du binaire Codex :</b>", use_markup=True, xalign=0), False, False, 0)
        bin_entry = Gtk.Entry()
        bin_entry.set_text(self.config.codex_bin_path)
        box.pack_start(bin_entry, False, False, 0)

        # Mock mode toggle
        mock_check = Gtk.CheckButton(label="Forcer le mode Simulation (Mock)")
        mock_check.set_active(self.config.enable_mock)
        box.pack_start(mock_check, False, False, 0)

        # Server status detail
        box.pack_start(Gtk.Label(label=f"Statut actuel : {self.pm.status} ({self.pm.status_detail})", xalign=0), False, False, 4)

        # Restart server button
        btn_restart = Gtk.Button.new_with_label("Redémarrer Codex app-server")
        def do_restart(_):
            self.config.codex_bin_path = bin_entry.get_text().strip()
            self.config.enable_mock = mock_check.get_active()
            self.config.save()
            self.pm.stop_server()
            self._start_server_async()
            dlg.response(Gtk.ResponseType.CLOSE)

        btn_restart.connect("clicked", do_restart)
        box.pack_start(btn_restart, False, False, 0)

        dlg.show_all()
        dlg.run()
        dlg.destroy()
