"""
Local SQLite persistence for Codex Desktop threads and messages.
"""

import sqlite3
import time
from pathlib import Path
from typing import List, Dict, Optional, Any

class Storage:
    def __init__(self, db_path: Path):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS threads (
                    id TEXT PRIMARY KEY,
                    title TEXT NOT NULL,
                    model TEXT NOT NULL,
                    cwd TEXT,
                    created_at REAL NOT NULL,
                    updated_at REAL NOT NULL
                )
            """)
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS messages (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    thread_id TEXT NOT NULL,
                    role TEXT NOT NULL,
                    content TEXT NOT NULL,
                    created_at REAL NOT NULL,
                    turn_id TEXT,
                    status TEXT DEFAULT 'completed',
                    FOREIGN KEY (thread_id) REFERENCES threads(id) ON DELETE CASCADE
                )
            """)
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_messages_thread ON messages(thread_id)")
            conn.commit()

    def save_thread(self, thread_id: str, title: str, model: str, cwd: str = "") -> Dict[str, Any]:
        now = time.time()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO threads (id, title, model, cwd, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(id) DO UPDATE SET
                    title = excluded.title,
                    updated_at = excluded.updated_at
            """, (thread_id, title, model, cwd, now, now))
            conn.commit()
        return {
            "id": thread_id,
            "title": title,
            "model": model,
            "cwd": cwd,
            "created_at": now,
            "updated_at": now
        }

    def update_thread_timestamp(self, thread_id: str, new_title: Optional[str] = None):
        now = time.time()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if new_title:
                cursor.execute("""
                    UPDATE threads SET updated_at = ?, title = ? WHERE id = ?
                """, (now, new_title, thread_id))
            else:
                cursor.execute("""
                    UPDATE threads SET updated_at = ? WHERE id = ?
                """, (now, thread_id))
            conn.commit()

    def list_threads(self) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, model, cwd, created_at, updated_at
                FROM threads
                ORDER BY updated_at DESC
            """)
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def get_thread(self, thread_id: str) -> Optional[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, title, model, cwd, created_at, updated_at
                FROM threads WHERE id = ?
            """, (thread_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def delete_thread(self, thread_id: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM messages WHERE thread_id = ?", (thread_id,))
            cursor.execute("DELETE FROM threads WHERE id = ?", (thread_id,))
            conn.commit()

    def add_message(self, thread_id: str, role: str, content: str, turn_id: Optional[str] = None, status: str = "completed") -> int:
        now = time.time()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO messages (thread_id, role, content, created_at, turn_id, status)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (thread_id, role, content, now, turn_id, status))
            msg_id = cursor.lastrowid
            conn.commit()
        self.update_thread_timestamp(thread_id)
        return msg_id

    def update_message(self, msg_id: int, content: str, status: str = "completed"):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE messages SET content = ?, status = ? WHERE id = ?
            """, (content, status, msg_id))
            conn.commit()

    def list_messages(self, thread_id: str) -> List[Dict[str, Any]]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, thread_id, role, content, created_at, turn_id, status
                FROM messages
                WHERE thread_id = ?
                ORDER BY id ASC
            """, (thread_id,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]
