"""
JSON-RPC 2.0 client for Codex app-server.
Communicates over bidirectional stdio streams using newline-delimited JSON (JSONL).
"""

import json
import logging
import threading
import time
from typing import Dict, Any, Callable, Optional

logger = logging.getLogger("codex_desktop.client")

class JsonRpcError(Exception):
    def __init__(self, code: int, message: str, data: Any = None):
        super().__init__(f"[{code}] {message}")
        self.code = code
        self.message = message
        self.data = data

class CodexClient:
    def __init__(self, stdin_stream=None, stdout_stream=None):
        self.stdin = stdin_stream
        self.stdout = stdout_stream
        self._msg_id = 0
        self._pending_requests: Dict[int, threading.Event] = {}
        self._pending_results: Dict[int, Any] = {}
        self._pending_errors: Dict[int, JsonRpcError] = {}
        self._lock = threading.Lock()
        self._running = False
        self._reader_thread: Optional[threading.Thread] = None

        # Callbacks
        self.on_notification: Optional[Callable[[str, Dict[str, Any]], None]] = None
        self.on_delta: Optional[Callable[[str, str], None]] = None  # (item_id, delta_text)
        self.on_turn_completed: Optional[Callable[[Dict[str, Any]], None]] = None
        self.on_approval_request: Optional[Callable[[str, int, Dict[str, Any]], str]] = None
        self.on_server_error: Optional[Callable[[Exception], None]] = None

    def start_reading(self, stdin_stream, stdout_stream):
        self.stdin = stdin_stream
        self.stdout = stdout_stream
        self._running = True
        self._reader_thread = threading.Thread(target=self._reader_loop, daemon=True, name="CodexClientReader")
        self._reader_thread.start()

    def stop(self):
        self._running = False
        with self._lock:
            for event in self._pending_requests.values():
                event.set()
            self._pending_requests.clear()

    def _next_id(self) -> int:
        with self._lock:
            self._msg_id += 1
            return self._msg_id

    def send_raw(self, payload: Dict[str, Any]):
        if not self.stdin:
            raise RuntimeError("Client is not connected to a server stream.")
        line = json.dumps(payload) + "\n"
        encoded = line.encode("utf-8")
        try:
            try:
                self.stdin.write(encoded)
            except TypeError:
                self.stdin.write(line)
            self.stdin.flush()
        except (BrokenPipeError, OSError) as e:
            logger.error("Failed to write to stdin: %s", e)
            if self.on_server_error:
                self.on_server_error(e)
            raise

    def request(self, method: str, params: Optional[Dict[str, Any]] = None, timeout: float = 30.0) -> Any:
        msg_id = self._next_id()
        payload = {
            "method": method,
            "id": msg_id,
            "params": params if params is not None else {}
        }
        event = threading.Event()
        with self._lock:
            self._pending_requests[msg_id] = event

        logger.debug("-> Request [%d] %s: %s", msg_id, method, params)
        self.send_raw(payload)

        finished = event.wait(timeout=timeout)
        with self._lock:
            self._pending_requests.pop(msg_id, None)
            err = self._pending_errors.pop(msg_id, None)
            res = self._pending_results.pop(msg_id, None)

        if not finished:
            raise TimeoutError(f"Request {method} (id={msg_id}) timed out after {timeout}s")
        if err:
            raise err
        return res

    def notify(self, method: str, params: Optional[Dict[str, Any]] = None):
        payload = {
            "method": method,
            "params": params if params is not None else {}
        }
        logger.debug("-> Notification %s: %s", method, params)
        self.send_raw(payload)

    def respond(self, req_id: int, result: Any = None, error: Optional[Dict[str, Any]] = None):
        payload: Dict[str, Any] = {"id": req_id}
        if error is not None:
            payload["error"] = error
        else:
            payload["result"] = result if result is not None else {}
        logger.debug("-> Response [%d]: %s", req_id, payload)
        self.send_raw(payload)

    def _reader_loop(self):
        try:
            while self._running:
                line = self.stdout.readline()
                if not line:
                    break
                if isinstance(line, bytes):
                    line = line.decode("utf-8", errors="replace")
                line = line.strip()
                if not line:
                    continue

                try:
                    msg = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning("Unparseable line from server: %s", line)
                    continue

                self._handle_incoming_message(msg)
        except Exception as e:
            logger.error("Error in reader loop: %s", e)
            if self.on_server_error:
                self.on_server_error(e)
        finally:
            self._running = False

    def _handle_incoming_message(self, msg: Dict[str, Any]):
        msg_id = msg.get("id")
        method = msg.get("method")

        # Case 1: Server response to our client request
        if msg_id is not None and method is None:
            with self._lock:
                if msg_id in self._pending_requests:
                    if "error" in msg:
                        err_dict = msg["error"]
                        self._pending_errors[msg_id] = JsonRpcError(
                            err_dict.get("code", -1),
                            err_dict.get("message", "Unknown error"),
                            err_dict.get("data")
                        )
                    else:
                        self._pending_results[msg_id] = msg.get("result")
                    self._pending_requests[msg_id].set()
            return

        # Case 2: Server-initiated request (e.g. approval request)
        if msg_id is not None and method is not None:
            self._handle_server_request(method, msg_id, msg.get("params", {}))
            return

        # Case 3: Server notification
        if method is not None and msg_id is None:
            self._handle_notification(method, msg.get("params", {}))
            return

    def _handle_server_request(self, method: str, req_id: int, params: Dict[str, Any]):
        logger.info("<- Server Request [%d] %s: %s", req_id, method, params)
        decision = "accept"
        if self.on_approval_request:
            try:
                decision = self.on_approval_request(method, req_id, params) or "accept"
            except Exception as e:
                logger.error("Error handling approval request: %s", e)
                decision = "decline"
        # Reply to approval
        self.respond(req_id, result={"decision": decision})

    def _handle_notification(self, method: str, params: Dict[str, Any]):
        logger.debug("<- Notification %s: %s", method, params)

        if method == "item/agentMessage/delta":
            delta = params.get("delta", "")
            item_id = params.get("itemId", "")
            if self.on_delta:
                self.on_delta(item_id, delta)

        elif method == "turn/completed":
            if self.on_turn_completed:
                self.on_turn_completed(params)

        if self.on_notification:
            try:
                self.on_notification(method, params)
            except Exception as e:
                logger.error("Error in on_notification handler: %s", e)

    # High-level Codex API wrappers
    def initialize(self, client_name="codex_desktop", version="1.0.0") -> Dict[str, Any]:
        params = {
            "clientInfo": {
                "name": client_name,
                "title": "Codex Desktop Linux",
                "version": version
            },
            "capabilities": {
                "experimentalApi": True
            }
        }
        res = self.request("initialize", params)
        self.notify("initialized", {})
        return res

    def thread_start(self, model="gpt-5.1-codex", cwd=None, approval_policy="onRequest", sandbox="workspaceWrite") -> str:
        params: Dict[str, Any] = {
            "model": model,
            "approvalPolicy": approval_policy,
            "sandbox": sandbox
        }
        if cwd:
            params["cwd"] = cwd
        res = self.request("thread/start", params)
        thread_obj = res.get("thread", {}) if isinstance(res, dict) else {}
        thread_id = thread_obj.get("id") or (res.get("id") if isinstance(res, dict) else str(res))
        return thread_id

    def thread_resume(self, thread_id: str) -> Dict[str, Any]:
        return self.request("thread/resume", {"threadId": thread_id})

    def thread_list(self, cursor=None, limit=50) -> Dict[str, Any]:
        params: Dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self.request("thread/list", params)

    def turn_start(self, thread_id: str, prompt_text: str, model=None) -> str:
        params: Dict[str, Any] = {
            "threadId": thread_id,
            "input": [
                {
                    "type": "text",
                    "text": prompt_text
                }
            ]
        }
        if model:
            params["model"] = model
        res = self.request("turn/start", params)
        turn_obj = res.get("turn", {}) if isinstance(res, dict) else {}
        return turn_obj.get("id", str(res))

    def turn_interrupt(self, thread_id: str, turn_id: str) -> Dict[str, Any]:
        return self.request("turn/interrupt", {"threadId": thread_id, "turnId": turn_id})
