"""
Configuration management for Codex Desktop Linux.
"""

import os
import json
from pathlib import Path

DEFAULT_DATA_DIR = Path.home() / ".local" / "share" / "codex-desktop"
DEFAULT_CONFIG_PATH = Path.home() / ".config" / "codex-desktop" / "config.json"

DEFAULT_MODELS = [
    ("gpt-5.1-codex", "GPT-5.1 Codex (Default)"),
    ("gpt-6.1-sol", "GPT-6.1 Sol (Advanced)"),
    ("gpt-5-mini", "GPT-5 Mini (Fast)"),
]

class Config:
    def __init__(self, config_path=None):
        self.config_path = Path(config_path) if config_path else DEFAULT_CONFIG_PATH
        self.data_dir = DEFAULT_DATA_DIR
        self.codex_bin_path = os.environ.get("CODEX_BIN", "")
        self.default_model = "gpt-5.1-codex"
        self.approval_policy = "onRequest"  # "never", "unlessTrusted", "onRequest"
        self.sandbox = "workspaceWrite"     # "readOnly", "workspaceWrite", "dangerFullAccess"
        self.enable_mock = False            # Enabled for testing/offline or fallback
        self.auto_start_server = True
        self.load()

    def ensure_directories(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

    def load(self):
        self.ensure_directories()
        if self.config_path.exists():
            try:
                with open(self.config_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    self.codex_bin_path = data.get("codex_bin_path", self.codex_bin_path)
                    self.default_model = data.get("default_model", self.default_model)
                    self.approval_policy = data.get("approval_policy", self.approval_policy)
                    self.sandbox = data.get("sandbox", self.sandbox)
                    self.enable_mock = data.get("enable_mock", self.enable_mock)
                    self.auto_start_server = data.get("auto_start_server", self.auto_start_server)
            except Exception as e:
                print(f"[Config] Error loading config: {e}")

    def save(self):
        self.ensure_directories()
        data = {
            "codex_bin_path": self.codex_bin_path,
            "default_model": self.default_model,
            "approval_policy": self.approval_policy,
            "sandbox": self.sandbox,
            "enable_mock": self.enable_mock,
            "auto_start_server": self.auto_start_server,
        }
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"[Config] Error saving config: {e}")
