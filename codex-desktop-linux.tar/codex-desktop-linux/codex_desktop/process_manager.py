"""
Process manager for Codex app-server.
Supervises launching, health checking, logging, and stopping the background daemon.
"""

import os
import sys
import shutil
import logging
import subprocess
import threading
from pathlib import Path
from typing import Optional, Callable
from codex_desktop.client import CodexClient
from codex_desktop.config import Config

logger = logging.getLogger("codex_desktop.process_manager")

class ServerStatus:
    STOPPED = "Arrêté"
    STARTING = "Démarrage..."
    RUNNING = "Connecté"
    MOCK_MODE = "Mode Simulation (Mock)"
    ERROR = "Erreur"

class ProcessManager:
    def __init__(self, config: Config):
        self.config = config
        self.process: Optional[subprocess.Popen] = None
        self.client: Optional[CodexClient] = None
        self.status = ServerStatus.STOPPED
        self.status_detail = ""
        self.is_mock = False
        self.on_status_change: Optional[Callable[[str, str], None]] = None
        self._stderr_thread: Optional[threading.Thread] = None

    def _set_status(self, status: str, detail: str = ""):
        self.status = status
        self.status_detail = detail
        logger.info("Server status changed: %s (%s)", status, detail)
        if self.on_status_change:
            try:
                self.on_status_change(status, detail)
            except Exception as e:
                logger.error("Error in on_status_change callback: %s", e)

    def find_codex_binary(self) -> Optional[str]:
        # 1. Custom configured path
        if self.config.codex_bin_path:
            p = Path(self.config.codex_bin_path).expanduser()
            if p.is_file() and os.access(p, os.X_OK):
                return str(p)

        # 2. In PATH
        path_binary = shutil.which("codex")
        if path_binary:
            return path_binary

        # 3. Common user installation locations on Linux
        candidates = [
            Path.home() / ".local" / "bin" / "codex",
            Path.home() / ".cargo" / "bin" / "codex",
            Path("/usr/local/bin/codex"),
            Path("/usr/bin/codex"),
            Path.home() / ".npm-global" / "bin" / "codex",
        ]
        nvm_dir = Path.home() / ".nvm" / "versions" / "node"
        if nvm_dir.exists():
            for node_v in nvm_dir.iterdir():
                candidates.append(node_v / "bin" / "codex")

        for cand in candidates:
            if cand.is_file() and os.access(cand, os.X_OK):
                return str(cand)

        return None

    def start_server(self) -> CodexClient:
        if self.process is not None and self.process.poll() is None:
            logger.info("Server already running.")
            return self.client

        self._set_status(ServerStatus.STARTING, "Recherche de Codex app-server...")
        codex_bin = self.find_codex_binary()

        use_mock = self.config.enable_mock or (codex_bin is None)

        if use_mock:
            self.is_mock = True
            logger.warning("Codex binary not found or mock mode enabled. Using embedded MockCodexAppServer.")
            mock_script = str(Path(__file__).parent / "mock_server.py")
            cmd = [sys.executable, mock_script]
            detail_msg = "Mock Server actif (aucun binaire codex détecté)" if not codex_bin else "Mode Mock forcé"
        else:
            self.is_mock = False
            cmd = [codex_bin, "app-server", "--listen", "stdio://"]
            detail_msg = f"Codex app-server démarré ({codex_bin})"

        try:
            self.process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=False,
                bufsize=0
            )

            # Start stderr logger
            self._stderr_thread = threading.Thread(target=self._log_stderr, daemon=True, name="CodexStderrReader")
            self._stderr_thread.start()

            # Initialize client
            self.client = CodexClient()
            self.client.on_server_error = self._on_client_error
            self.client.start_reading(self.process.stdin, self.process.stdout)

            # Perform JSON-RPC handshake
            init_res = self.client.initialize()
            logger.info("Handshake initialized: %s", init_res)

            status = ServerStatus.MOCK_MODE if self.is_mock else ServerStatus.RUNNING
            self._set_status(status, detail_msg)
            return self.client

        except Exception as e:
            logger.exception("Failed to start Codex server: %s", e)
            self._set_status(ServerStatus.ERROR, str(e))
            self.stop_server()
            raise

    def _log_stderr(self):
        if not self.process or not self.process.stderr:
            return
        try:
            for line in iter(self.process.stderr.readline, b""):
                text = line.decode("utf-8", errors="replace").strip()
                if text:
                    logger.debug("[app-server stderr] %s", text)
        except Exception:
            pass

    def _on_client_error(self, err: Exception):
        logger.error("Client transport error: %s", err)
        self._set_status(ServerStatus.ERROR, f"Erreur de communication: {err}")

    def stop_server(self):
        self._set_status(ServerStatus.STOPPED, "Arrêt du serveur...")
        if self.client:
            self.client.stop()
            self.client = None

        if self.process:
            try:
                if self.process.stdin:
                    try:
                        self.process.stdin.close()
                    except Exception:
                        pass
                if self.process.stdout:
                    try:
                        self.process.stdout.close()
                    except Exception:
                        pass
                if self.process.stderr:
                    try:
                        self.process.stderr.close()
                    except Exception:
                        pass
                self.process.terminate()
                self.process.wait(timeout=2.0)
            except Exception:
                try:
                    self.process.kill()
                except Exception:
                    pass
            self.process = None

        self._set_status(ServerStatus.STOPPED, "Serveur arrêté")

    def is_alive(self) -> bool:
        return self.process is not None and self.process.poll() is None
