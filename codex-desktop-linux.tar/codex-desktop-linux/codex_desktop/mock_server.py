"""
Mock Codex App Server for offline development, CI/CD testing, and demonstration.
Implements the exact Codex app-server JSON-RPC 2.0 stdio protocol.
"""

import sys
import json
import time
import uuid
import threading

class MockCodexAppServer:
    def __init__(self, stdin=sys.stdin, stdout=sys.stdout):
        self.stdin = stdin
        self.stdout = stdout
        self.running = True
        self.threads = {}

    def send(self, msg):
        line = json.dumps(msg) + "\n"
        if hasattr(self.stdout, "buffer"):
            self.stdout.buffer.write(line.encode("utf-8"))
            self.stdout.buffer.flush()
        else:
            self.stdout.write(line)
            self.stdout.flush()

    def run(self):
        for line in self.stdin:
            if not self.running:
                break
            if isinstance(line, bytes):
                line = line.decode("utf-8", errors="replace")
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            msg_id = data.get("id")
            method = data.get("method")
            params = data.get("params", {})

            if method == "initialize":
                self.send({
                    "id": msg_id,
                    "result": {
                        "serverInfo": {
                            "name": "mock_codex_app_server",
                            "version": "1.0.0"
                        },
                        "capabilities": {
                            "experimentalApi": True
                        }
                    }
                })
            elif method == "initialized":
                # Notification, no response needed
                pass
            elif method == "thread/start":
                thread_id = f"thr_{uuid.uuid4().hex[:12]}"
                self.threads[thread_id] = {
                    "id": thread_id,
                    "model": params.get("model", "gpt-5.1-codex"),
                    "cwd": params.get("cwd", ""),
                    "created_at": time.time()
                }
                self.send({
                    "id": msg_id,
                    "result": {
                        "thread": self.threads[thread_id]
                    }
                })
                # Emit thread/started notification
                self.send({
                    "method": "thread/started",
                    "params": {"thread": self.threads[thread_id]}
                })
            elif method == "thread/resume":
                thread_id = params.get("threadId")
                thread = self.threads.get(thread_id, {"id": thread_id, "model": "gpt-5.1-codex"})
                self.send({
                    "id": msg_id,
                    "result": {
                        "thread": thread
                    }
                })
            elif method == "thread/list":
                self.send({
                    "id": msg_id,
                    "result": {
                        "threads": list(self.threads.values()),
                        "nextCursor": None
                    }
                })
            elif method == "turn/start":
                thread_id = params.get("threadId")
                turn_id = f"turn_{uuid.uuid4().hex[:8]}"
                inputs = params.get("input", [])
                user_text = inputs[0].get("text", "") if inputs else ""

                # Immediate result acknowledging turn start
                self.send({
                    "id": msg_id,
                    "result": {
                        "turn": {
                            "id": turn_id,
                            "threadId": thread_id,
                            "status": "inProgress"
                        }
                    }
                })

                # Stream asynchronous notifications in a background thread
                threading.Thread(target=self._simulate_turn, args=(thread_id, turn_id, user_text), daemon=True).start()

            elif method == "turn/interrupt":
                self.send({
                    "id": msg_id,
                    "result": {"status": "interrupted"}
                })
            else:
                if msg_id is not None:
                    self.send({
                        "id": msg_id,
                        "error": {
                            "code": -32601,
                            "message": f"Method {method} not found"
                        }
                    })

    def _simulate_turn(self, thread_id: str, turn_id: str, user_text: str):
        # 1. Turn started
        self.send({
            "method": "turn/started",
            "params": {
                "turn": {
                    "id": turn_id,
                    "threadId": thread_id
                }
            }
        })
        time.sleep(0.05)

        # 2. Item started
        item_id = f"item_{uuid.uuid4().hex[:8]}"
        self.send({
            "method": "item/started",
            "params": {
                "turnId": turn_id,
                "item": {
                    "id": item_id,
                    "type": "agentMessage",
                    "status": "inProgress"
                }
            }
        })

        # 3. Stream deltas
        response_text = f"Bonjour ! Voici une réponse simulée de Codex pour votre message : « {user_text} ».\n\n" \
                        f"L'application Codex Desktop Linux communique avec succès avec Codex app-server via JSON-RPC 2.0."
        words = response_text.split(" ")
        for i, word in enumerate(words):
            delta = word + (" " if i < len(words) - 1 else "")
            self.send({
                "method": "item/agentMessage/delta",
                "params": {
                    "turnId": turn_id,
                    "itemId": item_id,
                    "delta": delta
                }
            })
            time.sleep(0.02)

        # 4. Item completed
        self.send({
            "method": "item/completed",
            "params": {
                "turnId": turn_id,
                "item": {
                    "id": item_id,
                    "type": "agentMessage",
                    "status": "completed",
                    "text": response_text
                }
            }
        })
        time.sleep(0.02)

        # 5. Turn completed
        self.send({
            "method": "turn/completed",
            "params": {
                "turn": {
                    "id": turn_id,
                    "threadId": thread_id,
                    "status": "completed"
                }
            }
        })

if __name__ == "__main__":
    server = MockCodexAppServer()
    server.run()
