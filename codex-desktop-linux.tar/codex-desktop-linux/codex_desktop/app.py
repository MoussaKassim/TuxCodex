"""
Main application runner for Codex Desktop Linux.
"""

import sys
import signal
import argparse
import logging
from pathlib import Path

import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk, GLib

from codex_desktop import __version__, __app_name__
from codex_desktop.config import Config
from codex_desktop.storage import Storage
from codex_desktop.process_manager import ProcessManager
from codex_desktop.ui import CodexDesktopWindow

def parse_args():
    parser = argparse.ArgumentParser(description=f"{__app_name__} v{__version__} - Client Linux pour Codex app-server")
    parser.add_argument("--version", action="version", version=f"{__app_name__} {__version__}")
    parser.add_argument("--debug", action="store_true", help="Activer les logs détaillés de débogage")
    parser.add_argument("--mock", action="store_true", help="Forcer l'utilisation du Mock Codex App Server")
    parser.add_argument("--config", type=str, help="Chemin vers un fichier de configuration alternatif")
    parser.add_argument("--codex-bin", type=str, help="Chemin explicite vers le binaire codex")
    return parser.parse_args()

def main():
    args = parse_args()

    log_level = logging.DEBUG if args.debug else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s",
        datefmt="%H:%M:%S"
    )

    config = Config(args.config)
    if args.mock:
        config.enable_mock = True
    if args.codex_bin:
        config.codex_bin_path = args.codex_bin

    db_path = config.data_dir / "codex_desktop.db"
    storage = Storage(db_path)
    pm = ProcessManager(config)

    win = CodexDesktopWindow(config, storage, pm)

    def on_window_destroy(widget):
        logging.info("Closing application. Stopping background Codex app-server...")
        pm.stop_server()
        Gtk.main_quit()

    win.connect("destroy", on_window_destroy)

    # Handle OS signals (SIGINT, SIGTERM)
    def sig_handler(sig, frame):
        GLib.idle_add(win.destroy)

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    win.show_all()
    Gtk.main()

if __name__ == "__main__":
    main()
