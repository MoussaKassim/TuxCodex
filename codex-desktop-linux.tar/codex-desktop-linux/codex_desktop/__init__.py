"""
Codex Desktop Linux - Unofficial Desktop Application for Codex.
"""

__version__ = "1.0.0"
__app_name__ = "Codex Desktop"
__app_id__ = "com.openai.codex.desktop"
