"""
End-to-end integration tests for Codex Desktop and Codex app-server protocol.
"""

import tempfile
import unittest
import threading
from pathlib import Path
from codex_desktop.config import Config
from codex_desktop.process_manager import ProcessManager

class TestCodexIntegration(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        cfg_path = Path(self.temp_dir.name) / "config.json"
        self.config = Config(cfg_path)
        self.config.enable_mock = True

        self.pm = ProcessManager(self.config)
        self.client = self.pm.start_server()

    def tearDown(self):
        self.pm.stop_server()
        self.temp_dir.cleanup()

    def test_full_thread_turn_lifecycle(self):
        # 1. Create a new thread
        thread_id = self.client.thread_start(model="gpt-5.1-codex")
        self.assertTrue(thread_id.startswith("thr_"))

        # 2. Track streamed deltas and completion
        received_chunks = []
        turn_done = threading.Event()

        def on_delta(item_id, delta):
            received_chunks.append(delta)

        def on_turn_completed(params):
            turn_done.set()

        self.client.on_delta = on_delta
        self.client.on_turn_completed = on_turn_completed

        # 3. Start a turn
        turn_id = self.client.turn_start(thread_id, "Explique-moi les threads Codex")
        self.assertTrue(turn_id.startswith("turn_"))

        # 4. Wait for streamed tokens and completion
        self.assertTrue(turn_done.wait(timeout=5.0), "Turn did not complete within timeout")
        full_response = "".join(received_chunks)
        self.assertIn("Bonjour", full_response)
        self.assertIn("Explique-moi les threads Codex", full_response)

        # 5. Test thread resumption
        resume_res = self.client.thread_resume(thread_id)
        self.assertIn("thread", resume_res)
        self.assertEqual(resume_res["thread"]["id"], thread_id)

if __name__ == "__main__":
    unittest.main()
