"""
Unit tests for CodexClient JSON-RPC 2.0 communication.
"""

import os
import json
import unittest
import threading
from codex_desktop.client import CodexClient, JsonRpcError

class TestCodexClient(unittest.TestCase):
    def test_request_and_response(self):
        # Use an OS pipe to simulate duplex stream
        r_fd, w_fd = os.pipe()
        read_stream = os.fdopen(r_fd, "rb", buffering=0)
        write_stream = os.fdopen(w_fd, "wb", buffering=0)

        in_pipe_r, in_pipe_w = os.pipe()
        client_stdin = os.fdopen(in_pipe_w, "wb", buffering=0)

        client = CodexClient()
        client.start_reading(client_stdin, read_stream)

        # Send response in a separate thread after request is sent
        def reply_worker():
            fake_response = json.dumps({"id": 1, "result": {"serverInfo": {"name": "test"}}}) + "\n"
            write_stream.write(fake_response.encode("utf-8"))
            write_stream.flush()

        threading.Thread(target=reply_worker, daemon=True).start()

        res = client.request("initialize", {"clientInfo": {"name": "test"}}, timeout=3.0)
        self.assertEqual(res["serverInfo"]["name"], "test")

        client.stop()
        read_stream.close()
        write_stream.close()
        client_stdin.close()
        os.close(in_pipe_r)

    def test_request_error_handling(self):
        r_fd, w_fd = os.pipe()
        read_stream = os.fdopen(r_fd, "rb", buffering=0)
        write_stream = os.fdopen(w_fd, "wb", buffering=0)

        in_pipe_r, in_pipe_w = os.pipe()
        client_stdin = os.fdopen(in_pipe_w, "wb", buffering=0)

        client = CodexClient()
        client.start_reading(client_stdin, read_stream)

        def reply_worker():
            fake_error = json.dumps({
                "id": 1,
                "error": {"code": -32601, "message": "Method not found"}
            }) + "\n"
            write_stream.write(fake_error.encode("utf-8"))
            write_stream.flush()

        threading.Thread(target=reply_worker, daemon=True).start()

        with self.assertRaises(JsonRpcError) as ctx:
            client.request("unknown_method", timeout=3.0)

        self.assertEqual(ctx.exception.code, -32601)
        self.assertIn("Method not found", ctx.exception.message)

        client.stop()
        read_stream.close()
        write_stream.close()
        client_stdin.close()
        os.close(in_pipe_r)

    def test_notification_handling(self):
        received_deltas = []
        turn_completed_event = threading.Event()

        r_fd, w_fd = os.pipe()
        read_stream = os.fdopen(r_fd, "rb", buffering=0)
        write_stream = os.fdopen(w_fd, "wb", buffering=0)

        in_pipe_r, in_pipe_w = os.pipe()
        client_stdin = os.fdopen(in_pipe_w, "wb", buffering=0)

        client = CodexClient()
        client.on_delta = lambda item_id, delta: received_deltas.append(delta)
        client.on_turn_completed = lambda params: turn_completed_event.set()

        client.start_reading(client_stdin, read_stream)

        fake_stream = (
            json.dumps({"method": "item/agentMessage/delta", "params": {"itemId": "item_1", "delta": "Hello"}}) + "\n" +
            json.dumps({"method": "item/agentMessage/delta", "params": {"itemId": "item_1", "delta": " world"}}) + "\n" +
            json.dumps({"method": "turn/completed", "params": {"turn": {"status": "completed"}}}) + "\n"
        )
        write_stream.write(fake_stream.encode("utf-8"))
        write_stream.flush()

        self.assertTrue(turn_completed_event.wait(timeout=3.0))
        self.assertEqual("".join(received_deltas), "Hello world")

        client.stop()
        read_stream.close()
        write_stream.close()
        client_stdin.close()
        os.close(in_pipe_r)

    def test_approval_request_handling(self):
        approval_called = []
        def on_approval(method, req_id, params):
            approval_called.append((method, req_id, params.get("command")))
            return "accept"

        r_fd, w_fd = os.pipe()
        read_stream = os.fdopen(r_fd, "rb", buffering=0)
        write_stream = os.fdopen(w_fd, "wb", buffering=0)

        in_pipe_r, in_pipe_w = os.pipe()
        client_stdin = os.fdopen(in_pipe_w, "wb", buffering=0)
        client_in_reader = os.fdopen(in_pipe_r, "rb", buffering=0)

        client = CodexClient()
        client.on_approval_request = on_approval
        client.start_reading(client_stdin, read_stream)

        fake_req = json.dumps({
            "id": 101,
            "method": "item/commandExecution/requestApproval",
            "params": {"itemId": "i1", "command": "ls -la"}
        }) + "\n"
        write_stream.write(fake_req.encode("utf-8"))
        write_stream.flush()

        # Read client's answer from client_in_reader
        line = client_in_reader.readline().decode("utf-8")
        data = json.loads(line)

        self.assertEqual(len(approval_called), 1)
        self.assertEqual(approval_called[0][2], "ls -la")
        self.assertEqual(data["id"], 101)
        self.assertEqual(data["result"]["decision"], "accept")

        client.stop()
        read_stream.close()
        write_stream.close()
        client_stdin.close()
        client_in_reader.close()

if __name__ == "__main__":
    unittest.main()
