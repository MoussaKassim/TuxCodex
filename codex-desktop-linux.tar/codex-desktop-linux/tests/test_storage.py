"""
Unit tests for Storage SQLite persistence.
"""

import tempfile
import unittest
from pathlib import Path
from codex_desktop.storage import Storage

class TestStorage(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test.db"
        self.storage = Storage(self.db_path)

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_save_and_list_threads(self):
        self.storage.save_thread("thr_1", "Chat 1", "gpt-5.1-codex", "/home/user")
        self.storage.save_thread("thr_2", "Chat 2", "gpt-6.1-sol", "/home/user/project")

        threads = self.storage.list_threads()
        self.assertEqual(len(threads), 2)
        ids = [t["id"] for t in threads]
        self.assertIn("thr_1", ids)
        self.assertIn("thr_2", ids)

    def test_messages_crud(self):
        self.storage.save_thread("thr_1", "Chat 1", "gpt-5.1-codex")

        m1_id = self.storage.add_message("thr_1", "user", "Hello Codex")
        m2_id = self.storage.add_message("thr_1", "assistant", "Hello! How can I help?", status="in_progress")

        messages = self.storage.list_messages("thr_1")
        self.assertEqual(len(messages), 2)
        self.assertEqual(messages[0]["content"], "Hello Codex")
        self.assertEqual(messages[1]["status"], "in_progress")

        self.storage.update_message(m2_id, "Hello! How can I help you today?", status="completed")
        updated = self.storage.list_messages("thr_1")
        self.assertEqual(updated[1]["content"], "Hello! How can I help you today?")
        self.assertEqual(updated[1]["status"], "completed")

    def test_delete_thread(self):
        self.storage.save_thread("thr_1", "To Delete", "gpt-5.1-codex")
        self.storage.add_message("thr_1", "user", "msg")

        self.storage.delete_thread("thr_1")
        self.assertIsNone(self.storage.get_thread("thr_1"))
        self.assertEqual(len(self.storage.list_messages("thr_1")), 0)

if __name__ == "__main__":
    unittest.main()
