"""
Unit tests for ProcessManager supervisor and lifecycle.
"""

import tempfile
import unittest
from pathlib import Path
from codex_desktop.config import Config
from codex_desktop.process_manager import ProcessManager, ServerStatus

class TestProcessManager(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        cfg_path = Path(self.temp_dir.name) / "config.json"
        self.config = Config(cfg_path)
        self.config.enable_mock = True  # Ensure deterministic mock server runs

    def tearDown(self):
        self.temp_dir.cleanup()

    def test_mock_server_lifecycle(self):
        pm = ProcessManager(self.config)
        self.assertEqual(pm.status, ServerStatus.STOPPED)

        client = pm.start_server()
        self.assertTrue(pm.is_alive())
        self.assertEqual(pm.status, ServerStatus.MOCK_MODE)
        self.assertIsNotNone(client)

        pm.stop_server()
        self.assertFalse(pm.is_alive())
        self.assertEqual(pm.status, ServerStatus.STOPPED)

if __name__ == "__main__":
    unittest.main()
